(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 2838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/dashboard.css
var dashboard = __webpack_require__(6797);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/context/useStore.js
var useStore = __webpack_require__(3920);
;// CONCATENATED MODULE: ./components/global/Alert.jsx



const Alert = ()=>{
    const store = (0,useStore/* default */.Z)();
    (0,external_react_.useEffect)(()=>{
        const timer = setTimeout(()=>{
            store?.setAlert(false);
        }, 5000);
        return ()=>{
            clearTimeout(timer);
        };
    }, [
        store.alert.msg
    ]);
    if (!store?.alert.msg) return null;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "alertContainer",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: store?.alert.type,
            children: store?.alert.msg
        })
    });
};
/* harmony default export */ const global_Alert = (Alert);

// EXTERNAL MODULE: ./components/context/StoreProvider.jsx + 1 modules
var StoreProvider = __webpack_require__(287);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/admin/AdminRoute.jsx




const AdminRoute = ({ children  })=>{
    const [loading, setLoading] = (0,external_react_.useState)(true);
    const router = (0,router_.useRouter)();
    const store = (0,useStore/* default */.Z)();
    const vendorRoute = /\/admin\/product|^\/admin\/product\/editproduct|\/admin\/product\/addproduct|\/admin\/coupon|\/admin\/coupon\/addcoupon|^\/admin\/coupon\/editcoupon|\/admin\/blog|\/admin\/blog\/addblog|^\/adming\/blog\/editbolg/;
    (0,external_react_.useEffect)(()=>{
        if (!store.loading && !store.user) {
            router.push("/login");
            store.setRedirect("/admin");
        } else if (!store.loading && store.user.user_role === "customer") {
            router.push("/");
        } else if (!store.loading && store.user.user_role !== "owner") {
            if (!vendorRoute.test(router.pathname)) {
                router.push("/admin/product");
                store.setRedirect("/admin");
            } else setLoading(false);
        } else if (!store.loading && store.user.user_role !== "customer") {
            setLoading(false);
        }
    }, [
        store.loading,
        store.user,
        router.pathname
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Loading..."
            })
        }) : children
    });
};
/* harmony default export */ const admin_AdminRoute = (AdminRoute);

;// CONCATENATED MODULE: ./components/admin/ProtectLoginPage.jsx




const ProtectLoginPage = ({ children  })=>{
    const [loading, setLoading] = (0,external_react_.useState)(true);
    const router = (0,router_.useRouter)();
    const store = (0,useStore/* default */.Z)();
    (0,external_react_.useEffect)(()=>{
        if (!store.loading && store.user) {
            router.push("/");
        } else if (!store.loading && !store.user) {
            setLoading(false);
        }
    }, [
        store.loading,
        store.user
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: loading ? null : children
    });
};
/* harmony default export */ const admin_ProtectLoginPage = (ProtectLoginPage);

;// CONCATENATED MODULE: ./pages/_app.js








function LayOut({ Component , pageProps  }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            router.pathname.startsWith("/admin") ? /*#__PURE__*/ jsx_runtime_.jsx(admin_AdminRoute, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            }) : router.pathname === "/login" ? /*#__PURE__*/ jsx_runtime_.jsx(admin_ProtectLoginPage, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            }) : /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(global_Alert, {})
        ]
    });
}
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(StoreProvider/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(LayOut, {
            Component: Component,
            pageProps: pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6797:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3920], () => (__webpack_exec__(2838)));
module.exports = __webpack_exports__;

})();