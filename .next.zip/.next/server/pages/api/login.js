"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
var external_bcryptjs_default = /*#__PURE__*/__webpack_require__.n(external_bcryptjs_);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
;// CONCATENATED MODULE: ./services/admin/server/login.js




async function getUser(req, res) {
    try {
        //send email for forget password;
        if (req.query.forgotPassword) {
            sendForgotPasswordLink(req, res);
        } else if (req.query.varifypasswordToken) {
            varifypasswordToken(req, res);
        } else if (req.query.varifyEmail) {
            varifyEmail(req, res);
        } else {
            if (!req.query.token) {
                throw {
                    message: "Unauthenticated",
                    status: 401
                };
            }
            const varify = external_jsonwebtoken_default().verify(req.query.token, process.env.JWT_SECRET);
            const database = varify.user_role === "vendor" ? "vandor" : "user";
            const sql = `SELECT * FROM ${database} WHERE id = ${varify.id} AND email = '${varify.email}'`;
            const user = await (0,mysql/* queryDocument */.zx)(sql);
            if (!user.length) throw {
                message: "Something went wrong"
            };
            delete user[0].password;
            const token = external_jsonwebtoken_default().sign({
                ...user[0]
            }, process.env.JWT_SECRET, {
                expiresIn: `${varify.user_role !== "customer" ? "3d" : "5h"}`
            });
            res.send({
                user: user[0],
                token
            });
        }
    } catch (error) {
        return (0,common/* errorHandler */.Po)(res, error);
    }
}
async function loginUser(req, res) {
    try {
        //social media login;
        if (req.query.socialLogin) {
            const sql = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result = await (0,mysql/* queryDocument */.zx)(sql);
            if (!result.length) {
                if ("5994471abb01112afcc18159f6cc74b4f511b99806da59b" !== req.body.password) {
                    throw {
                        message: "Forbiden",
                        status: 403
                    };
                }
                const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
                req.body.password = hashed;
                const sql1 = "INSERT INTO user ";
                const result1 = await (0,mysql/* postDocument */.UZ)(sql1, req.body);
                delete result1[0].password;
                const token = external_jsonwebtoken_default().sign({
                    ...result1[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: "3d"
                });
                res.send({
                    user: result1[0],
                    token
                });
            } else {
                const sql2 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
                const result2 = await (0,mysql/* queryDocument */.zx)(sql2);
                delete result2[0].password;
                const token1 = external_jsonwebtoken_default().sign({
                    ...result2[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: `${result2[0].user_role !== "customer" ? "3d" : "5h"}`
                });
                res.send({
                    user: result2[0],
                    token: token1
                });
            }
        } else {
            const sql3 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result3 = await (0,mysql/* queryDocument */.zx)(sql3);
            if (!result3.length) {
                const sql4 = `SELECT * FROM vandor WHERE email = '${req.body.email}'`;
                const result4 = await (0,mysql/* queryDocument */.zx)(sql4);
                if (!result4.length) {
                    throw {
                        message: "No user found",
                        status: 404
                    };
                } else {
                    sendUserInfo(req, res, result4);
                }
            } else {
                sendUserInfo(req, res, result3);
            }
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function signUpUser(req, res) {
    try {
        //update user password;
        if (req.query.updateuser) {
            const sql = `SELECT * FROM user WHERE id = '${req.body.id}' AND email = '${req.body.email}'`;
            const result = await (0,mysql/* queryDocument */.zx)(sql);
            if (!result.length) throw {
                message: "There was an error"
            };
            const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
            const query = `UPDATE user SET password='${hashed}' WHERE id=${req.body.id}`;
            const user = await (0,mysql/* queryDocument */.zx)(query);
            if (user.changedRows > 0) {
                const sql1 = `SELECT * FROM user WHERE id = '${req.body.id}'`;
                const result1 = await (0,mysql/* queryDocument */.zx)(sql1);
                const token = external_jsonwebtoken_default().sign({
                    ...result1[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: `${result1[0].user_role !== "customer" ? "3d" : "5h"}`
                });
                res.send({
                    message: "Your password updated successfully",
                    token
                });
            } else throw {
                message: "Unable to update, please try again"
            };
        } else {
            const sql2 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result2 = await (0,mysql/* queryDocument */.zx)(sql2);
            if (result2.length) throw {
                message: "User already exist",
                status: 409
            };
            const token1 = external_jsonwebtoken_default().sign(req.body, process.env.JWT_SECRET, {
                expiresIn: "1h"
            });
            const options = (0,common/* varifyEmailOpt */.hE)(req.body.email, token1);
            const email = await common/* mailer.sendMail */.Ei.sendMail(options);
            if (email.messageId) {
                res.send({
                    message: "An email sent to your email, please check"
                });
            } else throw {
                message: "There was an error"
            };
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function sendForgotPasswordLink(req, res) {
    try {
        const sql = `SELECT * FROM user WHERE email = '${req.query.forgotPassword}'`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (!result.length) {
            throw {
                message: "No user found",
                status: 404
            };
        }
        delete result[0].password;
        const token = external_jsonwebtoken_default().sign({
            ...result[0]
        }, process.env.JWT_SECRET, {
            expiresIn: "1h"
        });
        const options = (0,common/* forgotMailOpt */.FJ)(req.query.forgotPassword, token);
        const email = await common/* mailer.sendMail */.Ei.sendMail(options);
        if (email.messageId) {
            res.send({
                message: "An email sent to your email, please check"
            });
        } else throw {
            message: "There was an error"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function varifyEmail(req, res) {
    try {
        const varifyUser = external_jsonwebtoken_default().verify(req.query.varifyEmail, process.env.JWT_SECRET);
        if (!varifyUser) throw {
            message: "Token expired"
        };
        delete varifyUser.iat;
        delete varifyUser.exp;
        const hashedPassword = await external_bcryptjs_default().hash(varifyUser.password, 10);
        varifyUser.password = hashedPassword;
        const sql = "INSERT INTO user SET ";
        const user = (0,mysql/* postDocument */.UZ)(sql, varifyUser);
        if (user.insertId > 0) {
            const sql1 = `SELECT * FROM user WHERE id = '${result.insertId}'`;
            const result = (0,mysql/* queryDocument */.zx)(sql1);
            delete result[0].password;
            const token = external_jsonwebtoken_default().sign({
                ...result[0]
            }, process.env.JWT_SECRET, {
                expiresIn: "3d"
            });
            res.send({
                user: result[0],
                token
            });
        } else {
            res.send({
                message: "Unable to Added"
            });
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
function varifypasswordToken(req, res) {
    try {
        const result = external_jsonwebtoken_default().verify(req.query.varifypasswordToken, process.env.JWT_SECRET);
        if (!result) throw {
            message: "Token expired"
        };
        delete result.exp;
        delete result.iat;
        res.send(result);
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function sendUserInfo(req, res, result) {
    try {
        const isRightPassword = await external_bcryptjs_default().compare(req.body.password, result[0].password);
        if (!isRightPassword) {
            throw {
                message: "Username or password incorrect",
                status: 401
            };
        } else {
            delete result[0].password;
            const token = external_jsonwebtoken_default().sign({
                ...result[0]
            }, process.env.JWT_SECRET, {
                expiresIn: `${result[0].user_role !== "customer" ? "3d" : "5h"}`
            });
            res.send({
                user: result[0],
                token
            });
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/login.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getUser(req, res);
            break;
        case "POST":
            loginUser(req, res);
            break;
        case "PUT":
            signUpUser(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(4036)));
module.exports = __webpack_exports__;

})();