"use strict";
(() => {
var exports = {};
exports.id = 2514;
exports.ids = [2514];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 6680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/review.js



function getReview(req, res) {
    // send category for home category page;
    const limit = req.query.limit || 10;
    const page = parseInt(req.query.page || 0) * limit;
    const sql = `SELECT * FROM customer_review LIMIT ${page}, ${limit}`;
    const count = "SELECT COUNT(id) FROM customer_review";
    (0,common/* getDataFromDB */.zb)(res, sql, count);
}
const PostSchema = external_joi_default().object({
    customer_id: external_joi_default().number().required(),
    product_id: external_joi_default().number().required(),
    customer_name: external_joi_default().string().required(),
    customer_email: external_joi_default().string().email().required(),
    customer_profile: external_joi_default().string(),
    comment: external_joi_default().string().required(),
    rating: external_joi_default().number().max(5)
});
async function postReview(req, res) {
    try {
        //api validateion;
        const varify = PostSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const query = `SELECT id FROM user WHERE id = '${req.body.customer_id}' AND email = '${req.body.customer_email}'`;
        const isUser = await (0,mysql/* queryDocument */.zx)(query);
        if (!isUser.length) throw {
            message: "Forbiden",
            status: 401
        };
        const sql = "INSERT INTO customer_review SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Your Valueable Comment Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const DeleteSchema = external_joi_default().object({
    customer_id: external_joi_default().number().required(),
    customer_email: external_joi_default().string().email().required()
});
async function deleteReview(req, res) {
    try {
        //api validateion;
        const varify = DeleteSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const query = `SELECT id FROM customer_review WHERE customer_id = '${req.body.customer_id}' AND customer_email = '${req.body.customer_email}'`;
        const isUser = await (0,mysql/* queryDocument */.zx)(query);
        if (!isUser.length) throw {
            message: "Forbiden",
            status: 401
        };
        const sql = `DELETE FROM customer_review WHERE id=${req.query.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateReview(req, res) {
    try {
        const query = `SELECT id FROM customer_review WHERE id = '${req.query.id}' AND customer_id = '${req.body.customer_id}' AND customer_email = '${req.body.customer_email}'`;
        const isUser = await (0,mysql/* queryDocument */.zx)(query);
        if (!isUser.length) throw {
            message: "Forbiden",
            status: 401
        };
        delete req.body.customer_id;
        delete req.body.customer_email;
        const sql = `UPDATE customer_review SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Updated Successfull"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/review.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getReview(req, res);
            break;
        case "POST":
            postReview(req, res);
            break;
        case "PUT":
            updateReview(req, res);
            break;
        case "DELETE":
            deleteReview(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(6680)));
module.exports = __webpack_exports__;

})();