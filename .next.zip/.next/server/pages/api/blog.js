"use strict";
(() => {
var exports = {};
exports.id = 4745;
exports.ids = [4745];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 5284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/blog.js



function getBlog(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM blog WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else {
            // send category for home category page;
            const limit = req.query.limit || 10;
            const page = parseInt(req.query.page || 0) * limit;
            let sql1 = "";
            let count = "";
            if (req.query.user_type === "vendor") {
                sql1 = `SELECT * FROM blog WHERE user_id = '${req.query.user_id}' AND user_type = '${req.query.user_type}' LIMIT ${page}, ${limit}`;
                count = `SELECT COUNT(id) FROM blog WHERE user_id = '${req.query.user_id}' AND user_type = '${req.query.user_type}'`;
            } else {
                sql1 = `SELECT * FROM blog LIMIT ${page}, ${limit}`;
                count = "SELECT COUNT(id) FROM blog";
            }
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const FaqSchema = external_joi_default().object({
    title: external_joi_default().string().max(400).required(),
    body: external_joi_default().string().max(600).required(),
    user_id: external_joi_default().number().integer().required(),
    user_type: external_joi_default().string().required(),
    created_at: external_joi_default().date().required(),
    category_id: external_joi_default().number().integer().required(),
    category_name: external_joi_default().string().required(),
    sub_category_id: external_joi_default().number().integer(),
    sub_category_name: external_joi_default().string(),
    pro_sub_id: external_joi_default().number().integer(),
    pro_sub_name: external_joi_default().string()
});
async function postBlog(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        req.body.created_at = new Date();
        //api validateion;
        const varify = FaqSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const sql = "INSERT INTO blog SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Blog Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function deleteBlog(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        const sql = `DELETE FROM blog WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateBlog(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        const sql = `UPDATE blog SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Blog Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/blog.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getBlog(req, res);
            break;
        case "POST":
            postBlog(req, res);
            break;
        case "PUT":
            updateBlog(req, res);
            break;
        case "DELETE":
            deleteBlog(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(5284)));
module.exports = __webpack_exports__;

})();