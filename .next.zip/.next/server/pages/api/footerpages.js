"use strict";
(() => {
var exports = {};
exports.id = 4978;
exports.ids = [4978];
exports.modules = {

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 5565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/footerpages.js


function getFooterPages(req, res) {
    try {
        if (req.query.name) {
            //send single category;
            const sql = `SELECT * FROM footer_pages WHERE name = '${req.query.name}'`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else {
            //send all category
            const sql1 = "SELECT * FROM footer_pages";
            (0,common/* getDataFromDB */.zb)(res, sql1);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateFooterPages(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        const description = req.body.description.replace("'", "&#39;");
        const data = `description = '${description}'`;
        const sql = `UPDATE footer_pages SET ${data} WHERE name='${req.query.name}'`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.changedRows > 0) {
            res.send({
                message: `${req.query.name} Updated Successfully`
            });
        } else throw {
            message: "No Update found"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/footerpages.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getFooterPages(req, res);
            break;
        case "PUT":
            updateFooterPages(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(5565)));
module.exports = __webpack_exports__;

})();