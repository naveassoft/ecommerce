"use strict";
(() => {
var exports = {};
exports.id = 838;
exports.ids = [838];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 5307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/banner.js



function getBanner(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM banner WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM banner LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM banner";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM banner";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const bannerSchema = external_joi_default().object({
    category_id: external_joi_default().number().integer().required(),
    category_name: external_joi_default().string().required(),
    sub_category_id: external_joi_default().number().integer(),
    sub_category_name: external_joi_default().string(),
    image: external_joi_default().string().required()
});
async function postBanner(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error || !req.files.image) {
            throw {
                message: "Error occured when image updlading"
            };
        }
        req.body.image = req.files.image[0].filename;
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //api validateion;
        const varify = bannerSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const sql = "INSERT INTO banner SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql);
        if (result.insertId > 0) {
            res.send({
                message: "Banner Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        (0,common/* deleteImage */.ao)(req.body.image);
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function deleteBanner(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) throw {
            message: "Error occured when image updlading"
        };
        const sql = `DELETE FROM banner WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            (0,common/* deleteImage */.ao)(req.body.image);
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateBanner(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when image updlading"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        let exist;
        if (req.files.image) {
            req.body.image = req.files.image[0].filename;
            exist = req.body.existimage;
            delete req.body.existimage;
        }
        delete req.body.user_id;
        const sql = `UPDATE banner SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            if (exist) {
                (0,common/* deleteImage */.ao)(exist);
            }
            res.send({
                message: "Slider Updated Successfully"
            });
        } else throw {
            message: "Unable to Update, please try again"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/banner.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getBanner(req, res);
            break;
        case "POST":
            postBanner(req, res);
            break;
        case "PUT":
            updateBanner(req, res);
            break;
        case "DELETE":
            deleteBanner(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(5307)));
module.exports = __webpack_exports__;

})();