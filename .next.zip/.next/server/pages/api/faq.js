"use strict";
(() => {
var exports = {};
exports.id = 6481;
exports.ids = [6481];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/faq.js



function getFaq(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM faq WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM faq LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM faq";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM faq";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const FaqSchema = external_joi_default().object({
    question: external_joi_default().string().max(400).required(),
    answer: external_joi_default().string().max(600).required()
});
async function postFaq(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //api validateion;
        const varify = FaqSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const sql = "INSERT INTO faq SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Faq Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function deleteFaq(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        const sql = `DELETE FROM faq WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateFaq(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        const sql = `UPDATE faq SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Faq Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/faq.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getFaq(req, res);
            break;
        case "POST":
            postFaq(req, res);
            break;
        case "PUT":
            updateFaq(req, res);
            break;
        case "DELETE":
            deleteFaq(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(8176)));
module.exports = __webpack_exports__;

})();