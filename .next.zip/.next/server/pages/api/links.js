"use strict";
(() => {
var exports = {};
exports.id = 3116;
exports.ids = [3116];
exports.modules = {

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 1130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/links.js


function getLinks(req, res) {
    try {
        const sql = "SELECT * FROM important_links";
        (0,common/* getDataFromDB */.zb)(res, sql);
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateLinks(req, res) {
    try {
        const img = [
            {
                name: "logo",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        const document = JSON.parse(req.body.document);
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        let exist;
        if (req.files.logo) {
            document.push({
                name: "logo",
                info: req.files.logo[0].filename
            });
            exist = req.body.exist;
        }
        document.forEach(async (item)=>{
            const sql = `UPDATE important_links SET info = "${item.info}" WHERE name = "${item.name}"`;
            await (0,mysql/* queryDocument */.zx)(sql);
        });
        if (exist) (0,common/* deleteImage */.ao)(exist);
        res.send({
            message: "Updated successfully"
        });
    } catch (error1) {
        if (req.files.logo.length) {
            (0,common/* deleteImage */.ao)(req.files.logo[0].filename);
        }
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/links.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getLinks(req, res);
            break;
        case "PUT":
            updateLinks(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(1130)));
module.exports = __webpack_exports__;

})();