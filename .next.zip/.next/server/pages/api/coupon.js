"use strict";
(() => {
var exports = {};
exports.id = 8047;
exports.ids = [8047];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 3601:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/coupon.js



function getCoupon(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM coupon WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else {
            // send category for home category page;
            const limit = req.query.limit || 10;
            const page = parseInt(req.query.page || 0) * limit;
            let sql1 = "";
            let count = "";
            if (req.query.user_type === "vendor") {
                sql1 = `SELECT * FROM coupon WHERE user_id = '${req.query.user_id}' AND user_type = '${req.query.user_type}' LIMIT ${page}, ${limit}`;
                count = `SELECT COUNT(id) FROM coupon WHERE user_id = '${req.query.user_id}' AND user_type = '${req.query.user_type}'`;
            } else {
                sql1 = `SELECT * FROM coupon LIMIT ${page}, ${limit}`;
                count = "SELECT COUNT(id) FROM coupon";
            }
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const CouponSchema = external_joi_default().object({
    code: external_joi_default().string().max(50).required(),
    amount: external_joi_default().number().required(),
    type: external_joi_default().string().required(),
    user_id: external_joi_default().number().integer().required(),
    user_type: external_joi_default().string().required()
});
async function postCoupon(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        //api validateion;
        const varify = CouponSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const query = `SELECT id FROM coupon WHERE code = '${req.body.code}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) {
            throw {
                message: "Already exist"
            };
        }
        const sql = "INSERT INTO coupon SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Coupon Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function deleteCoupon(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.query.user, req.query.user_type);
        delete req.query.user;
        const sql = `DELETE FROM coupon WHERE id=${req.query.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateCoupon(req, res) {
    try {
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        const sql = `UPDATE coupon SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Coupon Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/coupon.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getCoupon(req, res);
            break;
        case "POST":
            postCoupon(req, res);
            break;
        case "PUT":
            updateCoupon(req, res);
            break;
        case "DELETE":
            deleteCoupon(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(3601)));
module.exports = __webpack_exports__;

})();