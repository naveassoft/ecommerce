"use strict";
(() => {
var exports = {};
exports.id = 8098;
exports.ids = [8098];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 990:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/subcategory.js



function getSubcategory(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM sub_category WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM sub_category LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM sub_category";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM sub_category";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const subCategorySchema = external_joi_default().object({
    name: external_joi_default().string().required(),
    category_id: external_joi_default().number().integer().required(),
    category_name: external_joi_default().string().required(),
    description: external_joi_default().string().max(500),
    image: external_joi_default().string().required()
});
async function postSubCategory(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error || !req.files.image) {
            throw {
                message: "Error occured when image updlading"
            };
        }
        req.body.image = req.files.image[0].filename;
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //api validateion;
        const varify = subCategorySchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const query = `SELECT id FROM sub_category WHERE name = '${req.body.name}' AND category_id = '${req.body.category_id}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) throw {
            message: "Already added"
        };
        const sql = "INSERT INTO sub_category SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Sub category Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        (0,common/* deleteImage */.ao)(req.body.image);
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function deletesubCategory(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        const sql = `DELETE FROM sub_category WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            (0,common/* deleteImage */.ao)(req.body.image);
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateSubtCategory(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when image updlading"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        let exist;
        if (req.files.image) {
            req.body.image = req.files.image[0].filename;
            exist = req.body.existimage;
            delete req.body.existimage;
        }
        const sql = `UPDATE sub_category SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            if (exist) {
                (0,common/* deleteImage */.ao)(exist);
            }
            res.send({
                message: "Category Updated Successfully"
            });
        } else throw {
            message: "Unable to Update, please try again"
        };
    } catch (error1) {
        if (req.body.image) (0,common/* deleteImage */.ao)(req.body.image);
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/subcategory.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getSubcategory(req, res);
            break;
        case "POST":
            postSubCategory(req, res);
            break;
        case "PUT":
            updateSubtCategory(req, res);
            break;
        case "DELETE":
            deletesubCategory(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(990)));
module.exports = __webpack_exports__;

})();