"use strict";
(() => {
var exports = {};
exports.id = 3222;
exports.ids = [3222];
exports.modules = {

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 2858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/dashboard.js


async function getDashboardData(req, res) {
    if (req.query.report) {
        sendReport(res);
    } else {
        sendDashboardData(res);
    }
}
async function sendReport(res) {
    try {
        //total product;
        const productsql = `SELECT COUNT(id) FROM product`;
        const productCount = await (0,mysql/* queryDocument */.zx)(productsql);
        const data = {};
        data.total_product = productCount[0]["COUNT(id)"];
        //total sales;
        const totalsql = `SELECT total FROM orders`;
        const totalSale = await (0,mysql/* queryDocument */.zx)(totalsql);
        let total = 0;
        for (const order of totalSale){
            total += order.total;
        }
        data.total_sale = total;
        // todays order;
        const date = new Date().toISOString().slice(0, 10);
        let yesterday = new Date(new Date().valueOf() - 1000 * 60 * 60 * 24).toISOString().slice(0, 10);
        const todaySalesql = `SELECT id FROM orders WHERE created_at BETWEEN ${date} AND  ${yesterday}`;
        const totalProduct = await (0,mysql/* queryDocument */.zx)(todaySalesql);
        data.todaysOrder = totalProduct.length;
        //pending order;
        const pendingOrdersql = `SELECT id FROM orders WHERE status = 'processing'`;
        const pendingOrder = await (0,mysql/* queryDocument */.zx)(pendingOrdersql);
        data.pendingOrder = pendingOrder.length;
        //canceled order;
        const canceledOrdersql = `SELECT id FROM orders WHERE status = 'canceled'`;
        const canceledOrder = await (0,mysql/* queryDocument */.zx)(canceledOrdersql);
        data.canceledOrder = canceledOrder.length;
        //Low stock product
        const lowStockProductsql = `SELECT id FROM product WHERE stock <= 5`;
        const lowStockProduct = await (0,mysql/* queryDocument */.zx)(lowStockProductsql);
        data.lowStockProduct = lowStockProduct.length;
        //top sold product
        const topSoldProductsql = `SELECT id FROM product WHERE delivered_order >= 20`;
        const topSoldProduct = await (0,mysql/* queryDocument */.zx)(topSoldProductsql);
        data.topSoldProduct = topSoldProduct.length;
        // total vandor
        const totalVandorsql = `SELECT id FROM vandor`;
        const totalVandor = await (0,mysql/* queryDocument */.zx)(totalVandorsql);
        data.totalVandor = totalVandor.length;
        res.send(data);
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function sendDashboardData(res) {
    try {
        const data = {};
        const topCustomersql = `SELECT id, profile, name FROM user ORDER BY order_placed LIMIT 5`;
        const topCustomer = await (0,mysql/* queryDocument */.zx)(topCustomersql);
        data.topCustomer = topCustomer;
        const topSalersql = `SELECT id, shop_logo, name FROM vandor ORDER BY delivered_order LIMIT 5`;
        const topSaler = await (0,mysql/* queryDocument */.zx)(topSalersql);
        data.topSaler = topSaler;
        const topProductsql = `SELECT id, main_image, name FROM product ORDER BY delivered_order LIMIT 5`;
        const topProduct = await (0,mysql/* queryDocument */.zx)(topProductsql);
        data.topProduct = topProduct;
        const topRatedProductsql = `SELECT DISTINCT customer_review.product_id as id, product.name, product.main_image FROM customer_review INNER JOIN product ON product.id = customer_review.product_id LIMIT 5`;
        const topRatedProduct = await (0,mysql/* queryDocument */.zx)(topRatedProductsql);
        data.topRatedProduct = topRatedProduct;
        res.send(data);
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/dashboard.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getDashboardData(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(2858)));
module.exports = __webpack_exports__;

})();