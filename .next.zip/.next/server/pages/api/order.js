"use strict";
(() => {
var exports = {};
exports.id = 8626;
exports.ids = [8626];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 2281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/order.js



async function getOder(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.query.user_id);
        if (req.query.id) {
            //send single order;
            const sql = `SELECT * FROM orders WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.date && req.query.status) {
            if (!req.query.start && !req.query.end) {
                throw {
                    message: "Start date and End date must be given"
                };
            }
            const limit = req.query.limit || 10;
            const page = parseInt(req.query.page || 0) * limit;
            const sql1 = `SELECT * FROM orders WHERE created_at >= '${req.query.start}' AND created_at <= '${req.query.end}' AND status = '${req.query.status}' LIMIT ${page}, ${limit}`;
            const count = `SELECT COUNT(id) FROM orders WHERE created_at BETWEEN '${req.query.start}' AND '${req.query.end}'`;
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else if (req.query.status) {
            const limit1 = req.query.limit || 10;
            const page1 = parseInt(req.query.page || 0) * limit1;
            const sql2 = `SELECT * FROM orders WHERE status = '${req.query.status}' LIMIT ${page1}, ${limit1}`;
            const count1 = `SELECT COUNT(id) FROM orders WHERE status = '${req.query.status}'`;
            (0,common/* getDataFromDB */.zb)(res, sql2, count1);
        } else if (req.query.date) {
            if (!req.query.start && !req.query.end) {
                throw {
                    message: "Start date and End date must be given"
                };
            }
            const limit2 = req.query.limit || 10;
            const page2 = parseInt(req.query.page || 0) * limit2;
            const sql3 = `SELECT * FROM orders WHERE created_at >= '${req.query.start}' AND created_at <= '${req.query.end}' LIMIT ${page2}, ${limit2}`;
            const count2 = `SELECT COUNT(id) FROM orders WHERE created_at BETWEEN '${req.query.start}' AND '${req.query.end}'`;
            (0,common/* getDataFromDB */.zb)(res, sql3, count2);
        } else if (req.query.customer) {
            const limit3 = req.query.limit || 10;
            const page3 = parseInt(req.query.page || 0) * limit3;
            const sql4 = `SELECT DISTINCT customer_id FROM orders LIMIT ${page3}, ${limit3}`;
            const customer = await (0,mysql/* queryDocument */.zx)(sql4);
            if (!customer.length) {
                throw {
                    message: "Not Found",
                    status: 404
                };
            }
            const customerId = [];
            customer.forEach((item)=>customerId.push(item.customer_id));
            const query = `SELECT * FROM user WHERE id IN(${customerId})`;
            const countsql = "SELECT DISTINCT customer_id FROM orders";
            const data = await (0,mysql/* queryDocument */.zx)(query);
            const count3 = await (0,mysql/* queryDocument */.zx)(countsql);
            res.send({
                count: count3.length,
                data
            });
        } else {
            const limit4 = req.query.limit || 10;
            const page4 = parseInt(req.query.page || 0) * limit4;
            const sql5 = `SELECT * FROM orders LIMIT ${page4}, ${limit4}`;
            const count4 = "SELECT COUNT(id) FROM orders";
            (0,common/* getDataFromDB */.zb)(res, sql5, count4);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const ProductSchema = external_joi_default().object().keys({
    product_id: external_joi_default().number().integer().required(),
    image: external_joi_default().string().required(),
    name: external_joi_default().string().required(),
    price: external_joi_default().number().required(),
    quantity: external_joi_default().number().required(),
    size: external_joi_default().string(),
    colour: external_joi_default().string()
});
const OrderSchema = external_joi_default().object({
    created_at: external_joi_default().date().required(),
    order_id: external_joi_default().string().required(),
    invoice_id: external_joi_default().string().required(),
    vandor_id: external_joi_default().number().integer().required(),
    sub_total: external_joi_default().number().required(),
    discount: external_joi_default().number().required(),
    tax: external_joi_default().number().required(),
    shipping_charge: external_joi_default().number().required(),
    total: external_joi_default().number().required(),
    customer_id: external_joi_default().number().integer().required(),
    customer_name: external_joi_default().string().required(),
    customer_email: external_joi_default().string().email().required(),
    shipping_address: external_joi_default().string().required(),
    customer_comment: external_joi_default().string(),
    customer_number: external_joi_default().string().required(),
    status: external_joi_default().string().valid("processing", "shipping", "delivered", "canceled"),
    delivery_date: external_joi_default().date().required(),
    payment_method: external_joi_default().string().valid("cash on delivery", "online payment"),
    product_info: external_joi_default().array().items(ProductSchema)
});
async function postOrder(req, res) {
    try {
        if (!req.body.product_info.length) {
            throw {
                message: "product not found"
            };
        }
        req.body.created_at = new Date();
        req.body.order_id = "OR-" + Date.now();
        req.body.invoice_id = "INV-" + Date.now();
        //api validateion;
        const varify = OrderSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        //check user is exist to db;
        const query_1 = `SELECT id number FROM user WHERE id = '${req.body.customer_id}' AND email = '${req.body.customer_email}'`;
        const isUser = await (0,mysql/* queryDocument */.zx)(query_1);
        if (!isUser.length) {
            throw {
                message: "Unknown user",
                status: 403
            };
        }
        //user esist  all done, go ahead;
        const product = req.body.product_info;
        const errors = [];
        product.forEach(async (item)=>{
            //now check stock whether available;
            const query_3 = `SELECT stock FROM product WHERE id = '${item.product_id}'`;
            const result = await (0,mysql/* queryDocument */.zx)(query_3);
            //product is not found in db;
            if (!result.length) {
                errors.push(item.product_id);
            } else if (result[0].stock < item.quantity) {
                errors.push(item.product_id);
            }
        });
        //is error exist, filter the product;
        if (errors.length) {
            const existedProduct = product.filter((item)=>{
                for(let i = 0; i < errors.length; i++){
                    if (item.product_id !== errors[i]) {
                        return true;
                    } else return false;
                }
            });
            req.body.product_info = existedProduct;
        }
        //if all product are invalid ;
        if (!req.body.product_info.length) {
            throw {
                message: "Forbidden",
                status: 403
            };
        }
        //finally save to db, all operation done;
        req.body.product_info = JSON.stringify(req.body.product_info);
        const query_4 = "INSERT INTO orders SET ";
        const order = await (0,mysql/* postDocument */.UZ)(query_4, req.body);
        if (order.insertId > 0) {
            JSON.parse(req.body.product_info).forEach(async (product)=>{
                const query_5 = `UPDATE product SET stock = stock - ${product.quantity} WHERE id= ${product.product_id}`;
                await (0,mysql/* queryDocument */.zx)(query_5);
            });
            //update user profile if not update
            if (isUser[0].number !== req.body.customer_number) {
                const query_2 = `UPDATE user SET number = '${req.body.customer_number}', address = '${req.body.shipping_address}'  WHERE id = '${req.body.customer_id}'`;
                await (0,mysql/* queryDocument */.zx)(query_2);
            }
            res.send({
                message: "Order Created Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateOrder(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        if (req.body.order_status === "delivered") {
            throw {
                message: "This order was delivered",
                status: 403
            };
        }
        const sql = `UPDATE orders SET status = '${req.body.status}' WHERE id=${req.query.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.changedRows == 0) {
            throw {
                message: "Unable to Update"
            };
        }
        const status = req.body.status;
        const orderStatus = req.body.order_status;
        if (orderStatus === "canceled" && status !== "canceled") {
            JSON.parse(req.body.products).forEach(async (product)=>{
                const query = `UPDATE product SET stock = stock - ${product.quantity} WHERE id= ${product.product_id}`;
                await (0,mysql/* queryDocument */.zx)(query);
                //update user;
                if (status === "delivered") {
                    updateUser(req, res, req.body.products);
                } else res.send({
                    message: "Order Updated Successfully"
                });
            });
        } else if (status === "delivered") {
            //update user;
            updateUser(req, res, req.body.products);
        } else if (status === "canceled") {
            JSON.parse(req.body.products).forEach(async (product)=>{
                const query = `UPDATE product SET stock = stock + ${product.quantity} WHERE id= ${product.product_id}`;
                await (0,mysql/* queryDocument */.zx)(query);
            });
            res.send({
                message: "Order Updated Successfully"
            });
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function deleteOrder(req, res) {
    try {
        const sql = `DELETE FROM orders WHERE id=${req.query.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updateUser(req, res, product) {
    try {
        const queryUser = `UPDATE user SET order_placed = order_placed + ${1} WHERE id= ${req.body.customer_id}`;
        await (0,mysql/* queryDocument */.zx)(queryUser);
        //update vendor;
        const queryVandor = `UPDATE vandor SET delivered_order = delivered_order + ${1} WHERE id= ${req.body.vendor_id}`;
        await (0,mysql/* queryDocument */.zx)(queryVandor);
        //update product;
        JSON.parse(product).forEach(async (pro)=>{
            const query = `UPDATE product SET delivered_order = delivered_order + ${1} WHERE id= ${pro.product_id}`;
            await (0,mysql/* queryDocument */.zx)(query);
        });
        res.send({
            message: "Order Updated Successfully"
        });
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/order.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getOder(req, res);
            break;
        case "POST":
            postOrder(req, res);
            break;
        case "PUT":
            updateOrder(req, res);
            break;
        case "DELETE":
            deleteOrder(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(2281)));
module.exports = __webpack_exports__;

})();