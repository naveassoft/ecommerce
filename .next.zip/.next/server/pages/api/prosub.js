"use strict";
(() => {
var exports = {};
exports.id = 1165;
exports.ids = [1165];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/prosub.js



function getProSub(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM pro_sub_category WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM pro_sub_category LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM pro_sub_category";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM pro_sub_category";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const prosubSchema = external_joi_default().object({
    name: external_joi_default().string().required(),
    sub_category_id: external_joi_default().number().integer().required(),
    sub_category_name: external_joi_default().string().required()
});
async function postProSub(req, res) {
    try {
        if (!req.body.user_id) {
            throw {
                message: "Forbiden",
                status: 403
            };
        }
        delete req.body.user_id;
        //api validateion;
        const varify = prosubSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const query = `SELECT id FROM pro_sub_category WHERE name = '${req.body.name}' AND sub_category_id = '${req.body.sub_category_id}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) throw {
            message: "Already added",
            status: 409
        };
        const sql = "INSERT INTO pro_sub_category SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Pro Sub Category Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function deleteProsub(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        const sql = `DELETE FROM pro_sub_category WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
async function updatetProsub(req, res) {
    try {
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        const sql = `UPDATE pro_sub_category SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Pro Sub Category Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}

;// CONCATENATED MODULE: ./pages/api/prosub.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getProSub(req, res);
            break;
        case "POST":
            postProSub(req, res);
            break;
        case "PUT":
            updatetProsub(req, res);
            break;
        case "DELETE":
            deleteProsub(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(174)));
module.exports = __webpack_exports__;

})();