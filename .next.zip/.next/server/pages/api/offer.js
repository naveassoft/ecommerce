"use strict";
(() => {
var exports = {};
exports.id = 9554;
exports.ids = [9554];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 1407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/offer.js



function getOffer(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM offer WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM offer LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM offer";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM offer";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const OfferSchema = external_joi_default().object({
    priority: external_joi_default().number().integer().required(),
    title: external_joi_default().string().required(),
    product_link: external_joi_default().string().required(),
    image: external_joi_default().string().required()
});
async function postOffer(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error || !req.files.image) {
            throw {
                message: "Error occured when image updlading"
            };
        }
        req.body.image = req.files.image[0].filename;
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //api validateion;
        const varify = OfferSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        const sql = "INSERT INTO offer SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Offer Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        (0,common/* deleteImage */.ao)(req.body.image);
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function deleteOffer(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        const sql = `DELETE FROM offer WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            (0,common/* deleteImage */.ao)(req.body.image);
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateOffer(req, res) {
    try {
        const img = [
            {
                name: "image",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when image updlading"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        let exist;
        if (req.files.image) {
            req.body.image = req.files.image[0].filename;
            exist = req.body.existimage;
            delete req.body.existimage;
        }
        const sql = `UPDATE offer SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            if (exist) {
                (0,common/* deleteImage */.ao)(exist);
            }
            res.send({
                message: "Offer Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error1) {
        if (req.body.image) (0,common/* deleteImage */.ao)(req.body.image);
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/offer.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getOffer(req, res);
            break;
        case "POST":
            postOffer(req, res);
            break;
        case "PUT":
            updateOffer(req, res);
            break;
        case "DELETE":
            deleteOffer(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(1407)));
module.exports = __webpack_exports__;

})();