"use strict";
(() => {
var exports = {};
exports.id = 2759;
exports.ids = [2759];
exports.modules = {

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/product.js



//get common function;
function sendSpecifiqData(req, res, name, query) {
    const limit = req.query.limit || 10;
    const page = parseInt(req.query.page || 0) * limit;
    let sql = "";
    let count = "";
    if (name && query) {
        sql = `SELECT * FROM product WHERE ${name} = '${query}' ORDER BY created_at DESC LIMIT ${page}, ${limit}`;
        count = "SELECT COUNT(id) FROM product";
    } else if (req.query.user_type === "vendor") {
        sql = `SELECT * FROM product WHERE created_by = '${req.query.user_id}' AND user_type = '${req.query.user_type}' ORDER BY created_at DESC LIMIT ${page}, ${limit}`;
        count = `SELECT COUNT(id) FROM product WHERE created_by = '${req.query.user_id}' AND user_type = '${req.query.user_type}'`;
    } else {
        sql = `SELECT * FROM product ORDER BY created_at DESC LIMIT ${page}, ${limit}`;
        count = "SELECT COUNT(id) FROM product";
    }
    (0,common/* getDataFromDB */.zb)(res, sql, count);
}
function getProduct(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM product WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.category) {
            //send all category product
            const limit = req.query.limit || 10;
            const page = parseInt(req.query.page || 0) * limit;
            const sql1 = `SELECT * FROM product WHERE category_id = '${req.query.category}' ORDER BY created_at DESC LIMIT ${page}, ${limit}`;
            const count = "SELECT COUNT(id) FROM product";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else if (req.query.subCategory) {
            //send all  sub category product
            sendSpecifiqData(req, res, "sub_category_id", req.query.subCategory);
        } else if (req.query.proSubCategory) {
            //send all category product
            sendSpecifiqData(req, res, "pro_sub_id", req.query.proSubCategory);
        } else {
            //send all product
            sendSpecifiqData(req, res);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const ProductSchema = external_joi_default().object({
    created_by: external_joi_default().number().integer().required(),
    user_type: external_joi_default().string().valid("vendor", "owner", "uploader").required(),
    created_at: external_joi_default().date().required(),
    name: external_joi_default().string().required(),
    brand: external_joi_default().string().required(),
    sku: external_joi_default().string().required(),
    price: external_joi_default().number().required(),
    prev_price: external_joi_default().number(),
    tax: external_joi_default().number(),
    stock: external_joi_default().number().required(),
    keyword: external_joi_default().string().required(),
    category_id: external_joi_default().number().integer().required(),
    category_name: external_joi_default().string().required(),
    sub_category_id: external_joi_default().number().integer(),
    sub_category_name: external_joi_default().string(),
    pro_sub_id: external_joi_default().number().integer(),
    pro_sub_name: external_joi_default().string(),
    short_description: external_joi_default().string().required(),
    description: external_joi_default().string().required(),
    main_image: external_joi_default().string().required(),
    features_img: external_joi_default().string().required(),
    type: external_joi_default().string().valid("single", "package").required(),
    colour: external_joi_default().string(),
    size: external_joi_default().string(),
    unit: external_joi_default().string().valid("piece", "kg"),
    qr_code: external_joi_default().string().required()
});
async function postProduct(req, res) {
    try {
        const img = [
            {
                name: "main_image",
                maxCount: 1
            },
            {
                name: "features_img",
                maxCount: 5
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error || !req.files.main_image || !req.files.features_img) {
            throw {
                message: "Error occured when image updlading"
            };
        }
        //images;
        req.body.main_image = req.files.main_image[0].filename;
        const features_img = [];
        req.files.features_img.forEach((img)=>{
            features_img.push(img.filename);
        });
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        delete req.body.user_id;
        req.body.created_at = new Date();
        req.body.features_img = JSON.stringify(features_img);
        //api validateion;
        const varify = ProductSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        //check sku is exist;
        const query = `SELECT * FROM product WHERE sku = '${req.body.sku}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) {
            throw {
                message: "Already this SKU added, try with different SKU"
            };
        }
        //procced to uploading product;
        const sql = "INSERT INTO product SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Product Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        resError(req, res, error1);
    }
}
async function deleteProduct(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        const sql = `DELETE FROM product WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            JSON.parse(req.body.image).forEach((img)=>{
                (0,common/* deleteImage */.ao)(img);
            });
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateProduct(req, res) {
    try {
        const img = [
            {
                name: "main_image",
                maxCount: 1
            },
            {
                name: "features_img",
                maxCount: 5
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) {
            throw {
                message: "Error occured when image updlading"
            };
        }
        await (0,common/* varifyUser */.g3)(req.body.user_id, req.body.user_type);
        delete req.body.user_id;
        if (Object.keys(req.body).length < 2) {
            throw {
                message: "No updated feild found",
                status: 404
            };
        }
        if (req.files.main_image) {
            req.body.main_image = req.files.main_image[0].filename;
        }
        const features_img = [];
        if (req.files.features_img) {
            req.files.features_img.forEach((img)=>{
                features_img.push(img.filename);
            });
        }
        if (req.body.needImage) {
            features_img.push(...JSON.parse(req.body.needImage));
            delete req.body.needImage;
        }
        if (features_img.length) {
            req.body.features_img = JSON.stringify(features_img);
        }
        let deleteImg;
        if (req.body.deleteImage) {
            deleteImg = JSON.parse(req.body.deleteImage);
            delete req.body.deleteImage;
        }
        const sql = `UPDATE product SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            if (deleteImg) {
                deleteImg.forEach((img)=>{
                    (0,common/* deleteImage */.ao)(img);
                });
            }
            res.send({
                message: "Product Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error1) {
        resError(req, res, error1);
    }
}
function resError(req, res, error) {
    if (req.files.main_image) {
        (0,common/* deleteImage */.ao)(req.files.main_image[0].filename);
    }
    if (req.files.features_img) {
        req.files.features_img.forEach((img)=>{
            (0,common/* deleteImage */.ao)(img.filename);
        });
    }
    (0,common/* errorHandler */.Po)(res, error);
}

;// CONCATENATED MODULE: ./pages/api/product.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getProduct(req, res);
            break;
        case "POST":
            postProduct(req, res);
            break;
        case "PUT":
            updateProduct(req, res);
            break;
        case "DELETE":
            deleteProduct(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(8945)));
module.exports = __webpack_exports__;

})();