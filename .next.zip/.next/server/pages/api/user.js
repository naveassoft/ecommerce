"use strict";
(() => {
var exports = {};
exports.id = 5541;
exports.ids = [5541];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
var external_bcryptjs_default = /*#__PURE__*/__webpack_require__.n(external_bcryptjs_);
// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/user.js




function getUser(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM user WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM user LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM user";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else if (req.query.filter) {
            const sql2 = `SELECT * FROM user WHERE user_role = '${req.query.filter}'`;
            (0,common/* getDataFromDB */.zb)(res, sql2);
        } else {
            //send all category
            const sql3 = "SELECT * FROM user";
            (0,common/* getDataFromDB */.zb)(res, sql3);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const UserSchema = external_joi_default().object({
    name: external_joi_default().string().max(100).required(),
    email: external_joi_default().string().email().required(),
    password: external_joi_default().string().min(6).required(),
    user_role: external_joi_default().string().valid("uploader", "owner").required(),
    profile: external_joi_default().string()
});
async function postUser(req, res) {
    try {
        const img = [
            {
                name: "profile",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //api validateion;
        const varify = UserSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        //check is user exist;
        const query = `SELECT * FROM user WHERE email='${req.body.email}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) throw {
            message: "User already exist",
            status: 409
        };
        //no user, you procced;
        //hased password;
        const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
        req.body.password = hashed;
        if (req.files.profile) {
            req.body.profile = req.files.profile[0].filename;
        } else delete req.body.profile;
        req.body.joined_at = new Date();
        //save to db;
        const sql = "INSERT INTO user SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "User Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        if (req.files.profile) {
            (0,common/* deleteImage */.ao)(req.files.profile[0].filename);
        }
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function deleteUser(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) {
            throw {
                message: "Error occured when parsing body"
            };
        }
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        const sql = `DELETE FROM user WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            if (req.body.image) {
                (0,common/* deleteImage */.ao)(req.body.image);
            }
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateUser(req, res) {
    try {
        const img = [
            {
                name: "profile",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        if (req.body.password) {
            const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
            req.body.password = hashed;
        }
        const sql = `UPDATE user SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "User Updated Successfully"
            });
        } else throw {
            message: "Unable to Update"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/user.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getUser(req, res);
            break;
        case "POST":
            postUser(req, res);
            break;
        case "PUT":
            updateUser(req, res);
            break;
        case "DELETE":
            deleteUser(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(4023)));
module.exports = __webpack_exports__;

})();