"use strict";
(() => {
var exports = {};
exports.id = 6570;
exports.ids = [6570];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1101:
/***/ ((module) => {

module.exports = require("joi");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 3642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
var external_bcryptjs_default = /*#__PURE__*/__webpack_require__.n(external_bcryptjs_);
// EXTERNAL MODULE: external "joi"
var external_joi_ = __webpack_require__(1101);
var external_joi_default = /*#__PURE__*/__webpack_require__.n(external_joi_);
// EXTERNAL MODULE: ./services/admin/mysql.js
var mysql = __webpack_require__(2382);
// EXTERNAL MODULE: ./services/admin/server/common.js
var common = __webpack_require__(6568);
;// CONCATENATED MODULE: ./services/admin/server/vandor.js




function getVandor(req, res) {
    try {
        if (req.query.id) {
            //send single category;
            const sql = `SELECT * FROM vandor WHERE id=${req.query.id}`;
            (0,common/* getDataFromDB */.zb)(res, sql);
        } else if (req.query.home) {
            // send category for home category page;
            const page = parseInt(req.query.page || 0) * req.query.limit;
            const sql1 = `SELECT * FROM vandor LIMIT ${page}, ${req.query.limit}`;
            const count = "SELECT COUNT(id) FROM vandor";
            (0,common/* getDataFromDB */.zb)(res, sql1, count);
        } else {
            //send all category
            const sql2 = "SELECT * FROM vandor";
            (0,common/* getDataFromDB */.zb)(res, sql2);
        }
    } catch (error) {
        (0,common/* errorHandler */.Po)(res, error);
    }
}
const VandorSchema = external_joi_default().object({
    name: external_joi_default().string().max(100).required(),
    email: external_joi_default().string().email().required(),
    number: external_joi_default().string().required(),
    shop_name: external_joi_default().string().max(100).required(),
    trad_liecence: external_joi_default().number().required(),
    shop_location: external_joi_default().string().required(),
    password: external_joi_default().string().min(6).required(),
    shop_logo: external_joi_default().string()
});
async function postVandor(req, res) {
    try {
        const img = [
            {
                name: "shop_logo",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        //check is user exist;
        const query = `SELECT * FROM vandor WHERE email='${req.body.email}'`;
        const isExist = await (0,mysql/* queryDocument */.zx)(query);
        if (isExist.length) throw {
            message: "User already exist"
        };
        //no user, you procced;
        //api validateion;
        const varify = VandorSchema.validate(req.body);
        if (varify.error) throw {
            message: varify.error.message
        };
        //hase password;
        const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
        req.body.password = hashed;
        if (req.files.shop_logo) {
            req.body.shop_logo = req.files.shop_logo[0].filename;
        } else delete req.body.shop_logo;
        //save to db;
        const sql = "INSERT INTO vandor SET ";
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Vandor Added Successfully"
            });
        } else throw {
            message: "Unable to Added"
        };
    } catch (error1) {
        if (req.files.shop_logo) {
            (0,common/* deleteImage */.ao)(req.files.shop_logo[0].filename);
        }
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function deleteVandor(req, res) {
    try {
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "", []);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        const sql = `DELETE FROM vandor WHERE id=${req.body.id}`;
        const result = await (0,mysql/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            if (req.body.shop_logo) {
                (0,common/* deleteImage */.ao)(req.body.image);
            }
            res.send({
                message: "Deleted successfully"
            });
        } else throw {
            message: "unable to delete"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}
async function updateVandor(req, res) {
    try {
        const img = [
            {
                name: "shop_logo",
                maxCount: 1
            }
        ];
        const { error  } = await (0,common/* bodyParser */.Ft)(req, res, "assets", img);
        if (error) throw {
            message: "Error occured when parsing body"
        };
        await (0,common/* varifyOwner */.PT)(req.body.user_id);
        delete req.body.user_id;
        if (req.body.password) {
            const hashed = await external_bcryptjs_default().hash(req.body.password, 10);
            req.body.password = hashed;
        }
        const sql = `UPDATE vandor SET `;
        const option = `WHERE id=${req.query.id}`;
        const result = await (0,mysql/* postDocument */.UZ)(sql, req.body, option);
        if (result.changedRows > 0) {
            res.send({
                message: "Vandor Updated Successfully"
            });
        } else throw {
            message: "Unable to Update, please try again"
        };
    } catch (error1) {
        (0,common/* errorHandler */.Po)(res, error1);
    }
}

;// CONCATENATED MODULE: ./pages/api/vandor.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getVandor(req, res);
            break;
        case "POST":
            postVandor(req, res);
            break;
        case "PUT":
            updateVandor(req, res);
            break;
        case "DELETE":
            deleteVandor(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6568], () => (__webpack_exec__(3642)));
module.exports = __webpack_exports__;

})();