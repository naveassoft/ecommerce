"use strict";
exports.id = 8109;
exports.ids = [8109];
exports.modules = {

/***/ 2993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_DashboardLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4961);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1211);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_DashboardLayout__WEBPACK_IMPORTED_MODULE_1__, _common_common__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__]);
([_common_DashboardLayout__WEBPACK_IMPORTED_MODULE_1__, _common_common__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ReportBody = ({ title , getOrderbyDate , setLimit , orders , count , limit , page , setPage  })=>{
    const { handleSubmit , register  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)();
    //total amount;
    let total = 0;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_DashboardLayout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "dashboard-home-container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_common__WEBPACK_IMPORTED_MODULE_3__/* .PageInfo */ .Sc, {
                    title: title,
                    type: "View",
                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaInfoCircle, {})
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "date-picker",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                onSubmit: handleSubmit(getOrderbyDate),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "md:flex gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                ...register("start_date", {
                                                    required: true
                                                }),
                                                type: "date"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                ...register("end_date", {
                                                    required: true
                                                }),
                                                type: "date"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn active",
                                        children: "Search"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_common__WEBPACK_IMPORTED_MODULE_3__/* .MainPagesTopPart */ .LN, {
                            setLimit: setLimit
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "table-container",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "ID"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "DATE"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "INVOICE"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    children: "TOTAL"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: orders && orders.length ? orders.map((item, i)=>{
                                            total += item.total;
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: `${i % 2 === 0 ? "bg-[#f1f1f1]" : "bg-[#f9f9f9]"}`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "sn-item",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        children: item.id
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: item.created_at.slice(0, 10)
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: item.invoice_id
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: item.total
                                                            })
                                                        ]
                                                    }),
                                                    orders.length - 1 === i && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            colSpan: 4,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex justify-end pr-5 text-yellow-700",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                                                                    children: [
                                                                        "Grand Total: ",
                                                                        total,
                                                                        " BDT"
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }, i);
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_common__WEBPACK_IMPORTED_MODULE_3__/* .NoDataFount */ .LR, {
                                            colSpan: 4
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_common__WEBPACK_IMPORTED_MODULE_3__/* .MainPagesFooterPart */ .gM, {
                            count: count,
                            limit: limit,
                            page: page,
                            setPage: setPage,
                            showingData: orders?.length || 0
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReportBody);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_useStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3920);



const initialState = {
    normal: true,
    date: false
};
const reducer = (state, action)=>{
    switch(action.type){
        case "normal":
            return {
                normal: true,
                date: null
            };
        case "date":
            return {
                normal: false,
                date: {
                    start_date: action.start_date,
                    end_date: action.end_date
                }
            };
        default:
            return {
                normal: true,
                date: null
            };
    }
};
const ReportHOC = (OriginalComponent, title)=>{
    return function NewComponent() {
        const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
        const [orders, setOrders] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
        const [limit, setLimit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(5);
        const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
        const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
        const store = (0,_context_useStore__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
        //get orders ;
        async function getAllOrder() {
            const { data , error  } = await store?.fetchData(`/api/order?status=${title}&limit=${limit}&page=${page}&user_id=${store.user.id}`);
            if (data) {
                setOrders(data.data);
                setCount(data.count);
            } else {
                store?.setAlert({
                    msg: error,
                    type: "error"
                });
            }
        }
        (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
            getAllOrder();
        }, []); //till
        //get order by date;
        async function getOrderbyDate(payload) {
            const { data , error  } = await store?.fetchData(`/api/order?date=true&status=delivered&start=${payload.start_date}&end=${payload.end_date}&limit=${limit}&page=${page}&user_id=${store.user.id}`);
            if (data) {
                setOrders(data.data);
                setCount(data.count);
                dispatch({
                    type: "date",
                    start_date: payload.start_date,
                    end_date: payload.end_date
                });
            } else {
                dispatch("normal");
                store?.setAlert({
                    msg: error,
                    type: "error"
                });
            }
        }
        //pagination;
        (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
            if (state.date) {
                getOrderbyDate(state.date);
            } else {
                getAllOrder();
            }
        }, [
            page,
            limit
        ]);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OriginalComponent, {
            count: count,
            getOrderbyDate: getOrderbyDate,
            limit: limit,
            orders: orders,
            page: page,
            setLimit: setLimit,
            setPage: setPage
        });
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReportHOC);


/***/ })

};
;