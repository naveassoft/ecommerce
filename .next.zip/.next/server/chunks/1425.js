"use strict";
exports.id = 1425;
exports.ids = [1425];
exports.modules = {

/***/ 1425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_facebook_login__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3739);
/* harmony import */ var react_facebook_login__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_facebook_login__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_google_login__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var gapi_script__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9203);
/* harmony import */ var gapi_script__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(gapi_script__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_useStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3920);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);







const SocialLogin = ({ setError  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const store = (0,_context_useStore__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const initClient = ()=>{
            gapi_script__WEBPACK_IMPORTED_MODULE_4__.gapi.auth2.init({
                apiKey: "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",
                clientId: "137211494718-58q0t25ntd3lbncjm9tttu131cdtm3q9.apps.googleusercontent.com",
                scope: "https://www.googleapis.com/auth/drive.metadata.readonly"
            });
        };
        gapi_script__WEBPACK_IMPORTED_MODULE_4__.gapi.load("client:auth2", initClient);
    }, []);
    async function googleLogin(response) {
        try {
            const data = {};
            data.email = response.profileObj.email;
            data.profile = response.profileObj.imageUrl;
            data.name = response.profileObj.name;
            data.password = "5994471abb01112afcc18159f6cc74b4f511b99806da59b";
            const res = await fetch("/api/login?socialLogin=true", {
                method: "POST",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(data)
            });
            const result = await res.json();
            if (res.ok) {
                store.setUser(result.user);
                localStorage.setItem("token", result.token);
                router.push(store?.redirect || "/");
            } else throw result;
        } catch (error) {
            setError(error.message);
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_login__WEBPACK_IMPORTED_MODULE_2___default()), {
                clientId: "137211494718-58q0t25ntd3lbncjm9tttu131cdtm3q9.apps.googleusercontent.com",
                render: (renderProps)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: renderProps.onClick,
                        disabled: renderProps.disabled,
                        type: "button",
                        className: "btn social-btn",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "h-8",
                                src: "/google.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Google"
                            })
                        ]
                    }),
                onSuccess: (response)=>googleLogin(response),
                onFailure: (response)=>setError(response.error),
                cookiePolicy: "single_host_origin"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_facebook_login__WEBPACK_IMPORTED_MODULE_1___default()), {
                appId: "438654467748573",
                fields: "name,email,picture",
                onClick: (response)=>console.log(response),
                callback: (response)=>console.log(response),
                icon: "fa-facebook",
                textButton: "Facebook",
                cssClass: "btn social-btn mt-3"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialLogin);


/***/ })

};
;