"use strict";
exports.id = 6568;
exports.ids = [6568];
exports.modules = {

/***/ 2382:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UZ": () => (/* binding */ postDocument),
/* harmony export */   "zx": () => (/* binding */ queryDocument)
/* harmony export */ });
/* unused harmony export mySql */
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2418);
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);

async function mySql() {
    const db = await mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createConnection({
        host: "localhost",
        user: "medicinelagbe_ecommerce",
        database: "medicinelagbe_ecommerce",
        password: "lCA!*c8ln)lZ",
        connectionLimit: 10,
        waitForConnections: true
    });
    return db;
}
// export async function mySql() {
//   const db = await mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     database: "ecommerce",
//     password: "",
//     connectionLimit: 10,
//     waitForConnections: true,
//   });
//   return db;
// }
const queryDocument = async (query)=>{
    const connection = await mySql();
    const result = await connection.execute(query);
    await connection.end();
    return result[0];
};
const postDocument = async (query, doc, option = undefined)=>{
    const connection = await mySql();
    let data = "";
    Object.entries(doc).forEach(([key, value])=>{
        if (data) {
            data += `, ${key} = '${value}'`;
        } else data += `${key} = '${value}'`;
    });
    if (option) data += option;
    const result = await connection.execute(query + data);
    await connection.end();
    return result[0];
};


/***/ }),

/***/ 6568:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ei": () => (/* binding */ mailer),
/* harmony export */   "FJ": () => (/* binding */ forgotMailOpt),
/* harmony export */   "Ft": () => (/* binding */ bodyParser),
/* harmony export */   "PT": () => (/* binding */ varifyOwner),
/* harmony export */   "Po": () => (/* binding */ errorHandler),
/* harmony export */   "ao": () => (/* binding */ deleteImage),
/* harmony export */   "g3": () => (/* binding */ varifyUser),
/* harmony export */   "hE": () => (/* binding */ varifyEmailOpt),
/* harmony export */   "zb": () => (/* binding */ getDataFromDB)
/* harmony export */ });
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1738);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(multer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5184);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nodemailer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mysql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2382);





const mailer = nodemailer__WEBPACK_IMPORTED_MODULE_3___default().createTransport({
    service: "gmail",
    auth: {
        user: "navieausa@gmail.com",
        pass: process.env.NODEMAILER_SECRET
    }
});
async function varifyOwner(user_id) {
    try {
        if (!user_id) throw {
            message: "Forbiden",
            status: 403
        };
        const sql = `SELECT id, user_role FROM user WHERE id = '${user_id}'`;
        const result = await (0,_mysql__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(sql);
        if (!result.length || result[0].user_role !== "owner") {
            throw {
                message: "Forbidden",
                status: 409
            };
        }
    } catch (error) {
        throw error;
    }
}
async function varifyUser(user_id, user_type) {
    try {
        if (!user_id && !user_type) {
            throw {
                message: "Forbiden",
                status: 403
            };
        }
        let sql = "";
        if (user_type === "vendor") {
            sql = `SELECT id, user_role FROM vandor WHERE id = '${user_id}'`;
        } else {
            sql = `SELECT id, user_role FROM user WHERE id = '${user_id}'`;
        }
        const result = await (0,_mysql__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(sql);
        if (!result.length || !/owner|uploader|vendor/.test(result[0].user_role)) {
            throw {
                message: "Forbidden",
                status: 409
            };
        }
    } catch (error) {
        throw error;
    }
}
async function getDataFromDB(res, query, count = undefined) {
    try {
        const data = await (0,_mysql__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(query);
        if (count) {
            const totalDocument = await (0,_mysql__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(count);
            res.send({
                count: totalDocument[0]["COUNT(id)"],
                data
            });
        } else res.send(data);
    } catch (error) {
        errorHandler(res, {
            message: error.message
        });
    }
}
async function bodyParser(req, res, folder, images) {
    try {
        const MulterConfiq = multer__WEBPACK_IMPORTED_MODULE_0___default()({
            storage: multer__WEBPACK_IMPORTED_MODULE_0___default().diskStorage({
                destination: function(req, file, cb) {
                    cb(null, path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "public", folder));
                },
                filename (req, file, cb) {
                    let fileName;
                    const isFavicon = req.files.favicon;
                    if (isFavicon) {
                        fileName = "favicon.ico";
                    } else {
                        fileName = `${file.fieldname}-${Date.now()}${path__WEBPACK_IMPORTED_MODULE_1___default().extname(file.originalname)}`;
                    }
                    cb(null, fileName);
                }
            }),
            fileFilter: (req, file, cb)=>{
                const filetypes = /jpg|jpeg|png|gif/;
                const extname = filetypes.test(path__WEBPACK_IMPORTED_MODULE_1___default().extname(file.originalname).toLowerCase());
                const mimetype = filetypes.test(file.mimetype);
                if (extname && mimetype) {
                    return cb(null, true);
                } else {
                    cb("Unsupported file extension");
                }
            },
            limits: 1000000
        });
        await new Promise((resolve)=>{
            const multer = MulterConfiq.fields(images);
            multer(req, res, resolve);
        });
        return {
            error: false
        };
    } catch (err) {
        return {
            error: err.message
        };
    }
}
function errorHandler(res, error) {
    console.log(error);
    res.status(error.status || 500).send({
        message: error.message || "Serverside error"
    });
}
function deleteImage(image) {
    try {
        fs__WEBPACK_IMPORTED_MODULE_2___default().unlinkSync(path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "public", "assets", image));
    } catch (error) {
        console.log(error);
    }
}
function forgotMailOpt(email, token) {
    return {
        from: "navieausa@gmail.com",
        to: email,
        subject: "Reset your password",
        html: html(`<div class="contentArea">
    <div class="section2">
      <h1>Forgot password ?</h1>
      <p class="mb-50">You/someone try to reset your account password. Here is the link to reset password.</p>
      <center><a href="http://localhost:3000/forgotpassword?token=${token}" class="confirmBtn">Reset Now</a></center>
      <p>If you have any question , just reply to this email, we're always happy to help out</p>
      <p class="mt-50">Cheers<br>The Team</p>
    </div>
  </div>`)
    };
}
function varifyEmailOpt(email, token) {
    return {
        from: "navieausa@gmail.com",
        to: email,
        subject: "Varify your Account",
        html: html(`<div class="contentArea">
    <div class="section2">
      <h1>Verify your account !</h1>
      <p class="mb-50">
        Thank you for signig up with Us! We hope you enjoy your time with us.
        Check your account and update your profile.
      </p>
      <center><a href="http://localhost:3000/varifyemail?token=${token}" class="confirmBtn">Verify Now</a></center>
      <p class="mt-50">
        if you have any question just reply to this email, We're always happy
        to help out.
      </p>
      <p class="mt-50">Cheers<br />The Team</p>
    </div>
  </div>`)
    };
}
function html(body) {
    return `<!DOCTYPE html>
    <html lang="en">
      <head>
        <style>
          body {
            padding: 0;
            margin: 0;
            background: #f7f8f8;
          }
          
          .contentArea {
            margin: 0 auto;
            display: block;
            width: 800px;
          }
          .section2 {
            background: #fff;
            margin-top: 50px;
            padding: 50px;
            font-family: Roboto, sans-serif;
          }
          .section2 h1 {
            font-size: 55px;
            text-align: center;
            letter-spacing: 5px;
            font-weight: 500;
          }
          .section2 p {
            font-size: 20px;
            color: #7aa182;
          }
          .mb-50 {
            margin-bottom: 50px;
          }
          .mt-50 {
            margin-top: 50px;
          }
          .confirmBtn {
            background: #16c1f3;
            color: #fff;
            padding: 10px 20px;
            border: none;
            font-size: 20px;
            text-decoration: none;
            border-radius: 5px;
          }
          .section2 .linkTag {
            color: #faa635;
            font-size: 20px;
          }
          @media only screen and (max-width: 800px) {
            .contentArea {
              width: 100%;
            }
          }
          @media only screen and (max-width: 550px) {
            .section2 h1 {
              font-size: 45px;
            }
            .section2 p {
              font-size: 18px;
            }
            .confirmBtn {
              font-size: 16px;
            }
            .section2 .linkTag {
              font-size: 18px;
            }
          }
        </style>
      </head>
      <body>   
        ${body}
      </body>
    </html>`;
}


/***/ })

};
;