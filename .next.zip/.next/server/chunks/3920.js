"use strict";
exports.id = 3920;
exports.ids = [3920];
exports.modules = {

/***/ 287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "_": () => (/* binding */ Context),
  "Z": () => (/* binding */ context_StoreProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/context/Store.js

const Store = ()=>{
    const [alert, setAlert] = (0,external_react_.useState)({
        msg: "",
        type: ""
    });
    const [user, setUser] = (0,external_react_.useState)(null);
    const [redirect, setRedirect] = (0,external_react_.useState)("/");
    const [loading, setLoading] = (0,external_react_.useState)(true);
    (0,external_react_.useEffect)(()=>{
        (async ()=>{
            try {
                const token = localStorage.getItem("token");
                if (token) {
                    const res = await fetch(`/api/login?token=${token}`);
                    const result = await res.json();
                    if (res.ok) {
                        setUser(result.user);
                        localStorage.setItem("token", result.token);
                    } else throw result;
                }
            } catch (error) {
                setUser(null);
                localStorage.removeItem("token");
            }
            setLoading(false);
        })();
    }, []);
    async function fetchData(url) {
        try {
            const res = await fetch(url);
            const data = await res.json();
            if (res.ok) {
                if (data) return {
                    data,
                    error: null
                };
                else throw {
                    message: "No data found"
                };
            } else throw data;
        } catch (error) {
            return {
                data: null,
                error: error.message
            };
        }
    }
    async function deleteData(url, formData) {
        try {
            const res = await fetch(url, {
                method: "DELETE",
                body: formData
            });
            const result = await res.json();
            if (res.ok) return {
                error: false,
                message: result.message
            };
            else throw result;
        } catch (error) {
            return {
                error: true,
                message: error.message
            };
        }
    }
    async function addOrEditData(url, formData, method) {
        try {
            const res = await fetch(url, {
                method: method,
                body: formData
            });
            const result = await res.json();
            if (res.ok) return {
                error: false,
                message: result.message
            };
            else throw result;
        } catch (error) {
            return {
                error: true,
                message: error.message
            };
        }
    }
    return {
        alert,
        setAlert,
        fetchData,
        deleteData,
        addOrEditData,
        user,
        setUser,
        redirect,
        setRedirect,
        loading
    };
};
/* harmony default export */ const context_Store = (Store);

;// CONCATENATED MODULE: ./components/context/StoreProvider.jsx



const Context = /*#__PURE__*/ (0,external_react_.createContext)(null);
const StoreProvider = ({ children  })=>{
    const store = context_Store();
    return /*#__PURE__*/ jsx_runtime_.jsx(Context.Provider, {
        value: store,
        children: children
    });
};
/* harmony default export */ const context_StoreProvider = (StoreProvider);


/***/ }),

/***/ 3920:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _StoreProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(287);


const useStore = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_StoreProvider__WEBPACK_IMPORTED_MODULE_1__/* .Context */ ._);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useStore);


/***/ })

};
;